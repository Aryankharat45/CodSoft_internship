import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from imblearn.over_sampling import SMOTE
import warnings

warnings.filterwarnings('ignore')


class FraudDetectionPipeline:
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.scaler = RobustScaler()
        self.best_model = None

    def load_data(self):
        """Generate synthetic data"""
        n_samples = 100  # Small for easy viewing
        fraud_rate = 0.1
        n_fraud = int(n_samples * fraud_rate)
        n_normal = n_samples - n_fraud

        normal = pd.DataFrame({
            'Amount': np.random.lognormal(3, 1.5, n_normal),
            'Feature1': np.random.normal(0, 1, n_normal),
            'Feature2': np.random.normal(0, 1, n_normal),
            'Class': 0
        })

        fraud = pd.DataFrame({
            'Amount': np.random.lognormal(2, 2, n_fraud),
            'Feature1': np.random.normal(2, 1.5, n_fraud),
            'Feature2': np.random.normal(-1, 1.2, n_fraud),
            'Class': 1
        })

        df = pd.concat([normal, fraud]).sample(frac=1).reset_index(drop=True)
        self.df = df
        return df

    def preprocess_data(self):
        X = self.df.drop('Class', axis=1)
        y = self.df['Class']

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, stratify=y, random_state=self.random_state)

        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)

        self.X_train, self.X_test = X_train, X_test
        self.y_train, self.y_test = y_train, y_test
        self.X_test_original = X.iloc[y_test.index]  # Save original features

    def train_model(self):
        smote = SMOTE(random_state=self.random_state)
        X_train_res, y_train_res = smote.fit_resample(self.X_train, self.y_train)

        model = RandomForestClassifier(random_state=self.random_state)
        model.fit(X_train_res, y_train_res)

        self.best_model = model
        y_pred = model.predict(self.X_test)

        # Display transaction-level table
        result_df = self.X_test_original.copy()
        result_df['Actual'] = self.y_test.values
        result_df['Predicted'] = y_pred
        result_df['Prediction_Label'] = result_df['Predicted'].map({0: 'Legitimate', 1: 'Fraudulent'})

        print("\n--- Transaction Prediction Table ---")
        print(result_df.head(20).to_string())  # Show first 20 rows

        # Save to CSV for full view
        result_df.to_csv("transaction_results.csv", index=False)
        print("\nFull table saved as **transaction_results.csv**")

        # Show confusion matrix and summary
        print("\nClassification Report:")
        print(classification_report(self.y_test, y_pred))

        cm = confusion_matrix(self.y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title("Confusion Matrix")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        plt.show()

    def run_pipeline(self):
        self.load_data()
        self.preprocess_data()
        self.train_model()


def main():
    pipeline = FraudDetectionPipeline()
    pipeline.run_pipeline()


if __name__ == "__main__":
    main()
